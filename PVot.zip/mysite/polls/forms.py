from django import forms


class EmailPostForm(forms.Form):
    first_name = forms.CharField(max_length=25, label='First name', label_suffix='')
    last_name = forms.CharField(max_length=25, label='Last name', label_suffix='')
    voter_id = forms.CharField(max_length=25, label='Voter id', label_suffix='')
